import time
from turtle import Screen
from gameturtle import GameTurtle
from car_manager import CarManager
from scoreboard import Scoreboard

screen = Screen()
screen.setup(width = 600, height = 600)
screen.bgcolor("black")
screen.tracer(0)

# Create obj
player_turtle = GameTurtle()
game_car = CarManager()
game_score_board = Scoreboard()

# Listen for button clicks
screen.listen()
screen.onkey(player_turtle.move_up, "Up")

game_is_on = True
while game_is_on:

    time.sleep(0.1)
    screen.update()

    game_car.create_car()
    game_car.move_cars()

    # Detect when turtle collides with car.
    # Loop through every car in the car list to check if the car hits any of those cars
    for car in game_car.list_cars:

        if car.distance(player_turtle) < 20:

            game_is_on = False
            game_score_board.game_over()

    # Detect when the turtle reaches the end of the grid
    if player_turtle.ycor() >= 280:

        player_turtle.game_level_increase()
        game_car.increase_speed()
        game_score_board.add_player_score()



screen.exitonclick()