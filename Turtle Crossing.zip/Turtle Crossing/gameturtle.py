from turtle import Turtle

STARTING_POSITION = (0, -280)
MOVE_DISTANCE = 10



class GameTurtle(Turtle):

    def __init__(self):

        super().__init__()

        self.penup()
        self.color("green")
        self.shape("turtle")
        self.goto(STARTING_POSITION)

        # Point Turtle North
        self.setheading(90)

    def move_up(self):

        # new_y == current y-cord + the move dist
        new_y = self.ycor() + MOVE_DISTANCE
        self.goto(self.xcor(), new_y)

    def game_level_increase(self):

        self.goto(STARTING_POSITION)