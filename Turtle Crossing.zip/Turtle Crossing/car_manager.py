from turtle import Turtle
import random

COLORS = ["red", "orange", "yellow", "green", "blue", "purple"]
STARTING_MOVE_DISTANCE = 5
MOVE_INCREMENT = 10


class CarManager:

    def __init__(self):

        self.list_cars = []
        self.speed = STARTING_MOVE_DISTANCE

    # Create a car, each new car will be an object of the turtle class
    # therefore when added to the "list_cars" attribute the list will contain
    # "new_car" objects, of type Turtle()
    def create_car(self):

        # Randomly decide when a car is made
        # This allows cars to be created less frequently so the screen
        # does not get overloaded with cars.
        random_chance = random.randint(1, 6)

        if random_chance == 1:

            new_car = Turtle()
            new_car.penup()
            new_car.shape("square")
            new_car.color(random.choice(COLORS))
            new_car.shapesize(stretch_len=2, stretch_wid=1)
            new_car.goto(300, random.randint(-250, 250))

            self.list_cars.append(new_car)

    def move_cars(self):

        # the variables within the list_cars are all objects of the Turtle() Class.
        # See above method "create_car" for details
        for car in self.list_cars:

            # Move backwards because we are starting at the right side of the grid,
            # and want to move to the left. Which deincrements the x-cord, moving the car along
            # the x-axis to the left.
            car.backward(self.speed)

    def increase_speed(self):

        self.speed += 10
        print(self.speed)